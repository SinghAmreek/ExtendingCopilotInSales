namespace CompanyName.ExtendedSummary.Services
{
    using System;
    using System.Collections.Generic;
    using CompanyName.ExtendedSummary.Constants;
    using CompanyName.ExtendedSummary.Models;
    using Microsoft.Xrm.Sdk;

    /// <summary>
    /// Service to fetch and process customer-extended summary data from CDS or external data sources.
    /// </summary>
    public class ExtendedSummaryDataService(
        IPluginExecutionContext localPluginContext,
        IServiceProvider serviceProvider,
        string entityName,
        string entityId,
        string activityId
    )
    {
        private readonly IPluginExecutionContext localPluginContext = localPluginContext;
        private readonly IServiceProvider serviceProvider = serviceProvider;
        private readonly string entityName = entityName;
        private readonly string entityId = entityId;
        private readonly string activityId = activityId;
        private readonly EntityFetchService entityFetchService = new(localPluginContext, serviceProvider);

        public ExtendedSummaryOutput? GetExtendedSummaryOutput()
        {
            // Add logic-switches here based on entity type input (for supported extended entities)
            if (entityName == EntityLogicalName.Account || entityName == EntityLogicalName.Opportunity)
            {
                List<FieldData> unsummarizedFields = GetUnsummarizedFieldsData();
                BaseSummarySection baseSummarySection = GetExtendedBaseSummarySection();
                List<SummaryContainer> extendedSummarySections = GetExtendedSummaryContainers();

                return new ExtendedSummaryOutput(unsummarizedFields, baseSummarySection, extendedSummarySections);
            }
            else
            {
                return null;
            }
        }

        private List<FieldData> GetUnsummarizedFieldsData()
        {
            // TODO: Update this method implementation to retrieve unsummarized fields data

            var fields = DummyData.GetFields();

            var randomEntityRefField = GetRandomEntityRefField();
            if (randomEntityRefField != null)
            {
                fields.Add(randomEntityRefField);
            }

            return fields;
        }

        private FieldData? GetRandomEntityRefField()
        {
            string logicalName = GetRandomEntityType();

            Entity? randomEntity = entityFetchService.FetchRandomEntity(logicalName);
            if (randomEntity is null)
            {
                return null;
            }

            return new(
                $"random_{logicalName}",
                $"Random {logicalName}",
                $"{logicalName} entity reference for a random record from the org.",
                new EntityReference(logicalName, randomEntity.Id) { Name = $"Random {logicalName}" }
            );
        }

        private BaseSummarySection GetExtendedBaseSummarySection()
        {
            // TODO: Update this method implementation to retrieve summarized base section

            return DummyData.GetBaseSummarySection(entityName, entityId);
        }

        private List<SummaryContainer> GetExtendedSummaryContainers()
        {
            // TODO: Update this method implementation to retrieve summarized containers

            return DummyData.GetSummaryContainers(entityName, entityId);
        }

        private static string GetRandomEntityType()
        {
            string[] logicalNames = [EntityLogicalName.Account, EntityLogicalName.Opportunity, EntityLogicalName.Lead];

            Random random = new();
            return logicalNames[random.Next(logicalNames.Length)];
        }
    }
}
