namespace CompanyName.ExtendedSummary.Services
{
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;
    using System;

    public class EntityFetchService(IPluginExecutionContext localPluginContext, IServiceProvider serviceProvider)
    {
        private readonly IPluginExecutionContext localPluginContext = localPluginContext;
        private readonly IServiceProvider serviceProvider = serviceProvider;

        /// <summary>
        /// Fetches a random entity from CDS.
        /// </summary>
        /// <remarks>Used to test out entity fetch and adding entity reference links as fields.
        public Entity? FetchRandomEntity(string entityName)
        {
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)
                serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(localPluginContext.UserId);

            // QueryExpression to fetch a single entity (only ID).
            var query = new QueryExpression(entityName)
            {
                ColumnSet = new ColumnSet(false),
                PageInfo = new PagingInfo() { PageNumber = 1, Count = 1 },
            };

            EntityCollection results = service.RetrieveMultiple(query);
            if (
                results.Entities.Count > 0
                && results.Entities[0] is Entity randomEntity
                && randomEntity.Id != Guid.Empty
            )
            {
                return randomEntity;
            }

            return null;
        }
    }
}
