namespace CompanyName.ExtendedSummary.Utilities
{
    using CompanyName.ExtendedSummary.Models;
    using Microsoft.Xrm.Sdk;

    public static class PluginContextUtility
    {
        private static class OutputParamater
        {
            public const string ExtendedSummaryData = "msdyn_extendedSummaryData";
        }

        private static class SummaryDataKey
        {
            public const string ExtendedSummaryFields = "msdyn_extendedSummaryFields";
            public const string BaseSummarySection = "msdyn_baseSummarySection";
            public const string SummaryContainers = "msdyn_summaryContainers";
        }

        public static void UpdateOutput(
            IPluginExecutionContext localPluginContext,
            ExtendedSummaryOutput? extendedSummaryOutput
        )
        {
            if (extendedSummaryOutput is null)
            {
                return;
            }

            ParameterCollection outputParameters = localPluginContext.OutputParameters;
            var outputEntity = (Entity)outputParameters[OutputParamater.ExtendedSummaryData];

            // Unsummarized fields
            var summaryFieldsResponse = new Entity();
            foreach (var fieldData in extendedSummaryOutput.UnsummarizedFields)
            {
                summaryFieldsResponse[fieldData.LogicalName] = fieldData.ToResponseEntity();
            }
            outputEntity[SummaryDataKey.ExtendedSummaryFields] = summaryFieldsResponse;

            // Base summary section
            outputEntity[SummaryDataKey.BaseSummarySection] =
                extendedSummaryOutput.BaseSummarySection.ToResponseEntity();

            // Summary containers
            var summaryContainersResponse = new Entity();
            foreach (var section in extendedSummaryOutput.ExtendedSummarySections)
            {
                summaryContainersResponse[section.Id] = section.ToResponseEntity();
            }
            outputEntity[SummaryDataKey.SummaryContainers] = summaryContainersResponse;
        }
    }
}
