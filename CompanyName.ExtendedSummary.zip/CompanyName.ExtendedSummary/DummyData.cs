namespace CompanyName.ExtendedSummary
{
    using System;
    using System.Collections.Generic;
    using CompanyName.ExtendedSummary.Models;
    using Microsoft.Xrm.Sdk;

    /// <summary>
    /// Dummy data to demonstrate the different types of data outputs in the extended summary response.
    /// </summary>
    public static class DummyData
    {
        public static BaseSummarySection GetBaseSummarySection(string entityName, string entityId)
        {
            return new(
                "- [Bing](https://www.bing.com/) is a valuable website.\r\n- Bing is owned by [Microsoft](https://en.wikipedia.org/wiki/Microsoft) and has a Credit Limit of $500,000.00.\r\n- Its Ownership structure is Public.",
                "Bing is a valuable website.\r\nBing is owned by Microsoft and has a Credit Limit of $500,000.00.\r\nIts Ownership structure is Public."
            );
        }

        public static List<SummaryContainer> GetSummaryContainers(string entityName, string entityId)
        {
            return
            [
                new(
                    "inputDetailsSummarySection",
                    $"- The entityName is {entityName}.\r\n- The entityId is {entityId}.\r\n- This is the [record link](main.aspx?pagetype=entityrecord&etn={entityName}&id={entityId}).",
                    $"The entityName is {entityName}.\r\nThe entityId is {entityId}.\r\nThis is the record link.",
                    0,
                    "Extended summary insights"
                ),
                new(
                    "summary1Key",
                    "- Copilot is part of [Dynamics 365 Sales](https://www.microsoft.com/en-in/dynamics-365/products/sales).\r\n- Close more deals and increase seller efficiency with an AI-powered CRM solution.\r\n- It has different pricing options.",
                    "Copilot is part of Dynamics 365 Sales.\r\nClose more deals and increase seller efficiency with an AI-powered CRM solution.\r\nIt has different pricing options.",
                    2,
                    "Customer extended summary"
                ),
            ];
        }

        public static List<FieldData> GetFields()
        {
            return
            [
                new(
                    "stockVolatility",
                    "Stock Volatility",
                    "Represents the stock price volatility over the past year.",
                    0.3
                ),
                new(
                    "riskAssessment",
                    "Risk Assessment",
                    "The risk level associated with this account. Can be Low, Medium, or High.",
                    "Low"
                ),
                new("marketShare", "Market Share", "The percentage of market share held by this account.", 15.2),
                new(
                    "ceoContact",
                    "CEO Contact",
                    "The contact record entity reference for the CEO of this account.",
                    new EntityReference("contact", new Guid("678c7b32-3f72-ea11-a811-000d3a1b1f2c"))
                    {
                        Name = "Kevin Martin",
                    }
                ),
            ];
        }
    }
}
