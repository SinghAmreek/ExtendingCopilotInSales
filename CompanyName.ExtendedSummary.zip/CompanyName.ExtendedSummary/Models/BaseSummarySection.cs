namespace CompanyName.ExtendedSummary.Models
{
    using CompanyName.ExtendedSummary.Interfaces;
    using Microsoft.Xrm.Sdk;

    /// <summary>
    /// Summary section added the main entity summary bullet points.
    /// </summary>
    public class BaseSummarySection(string markdownSummary, string plaintextSummary)
        : SummaryLine(markdownSummary, plaintextSummary),
            IResponseItem
    {
        public Entity ToResponseEntity()
        {
            return new()
            {
                Attributes = new() { [MarkdownSummaryKey] = MarkdownSummary, [PlaintextSummaryKey] = PlaintextSummary },
            };
        }
    }
}
