namespace CompanyName.ExtendedSummary.Models
{
    using CompanyName.ExtendedSummary.Interfaces;
    using Microsoft.Xrm.Sdk;

    /// <summary>
    /// Individual summary container for a group of summary lines.
    /// </summary>
    public class SummaryContainer(string id, string markdownSummary, string plaintextSummary, int order, string header)
        : SummaryLine(markdownSummary, plaintextSummary),
            IResponseItem
    {
        private const string HeaderKey = "header";
        private const string OrderKey = "order";

        /// <summary>
        /// Identifier for the summary container.
        /// </summary>
        public string Id { get; set; } = id;

        /// <summary>
        /// Header for the summary container.
        /// </summary>
        public string Header { get; set; } = header;

        /// <summary>
        /// Order of the summary container.
        /// </summary>
        public int Order { get; set; } = order;

        public Entity ToResponseEntity()
        {
            return new()
            {
                Attributes = new()
                {
                    [HeaderKey] = Header,
                    [MarkdownSummaryKey] = MarkdownSummary,
                    [PlaintextSummaryKey] = PlaintextSummary,
                    [OrderKey] = Order
                }
            };
        }
    }
}
