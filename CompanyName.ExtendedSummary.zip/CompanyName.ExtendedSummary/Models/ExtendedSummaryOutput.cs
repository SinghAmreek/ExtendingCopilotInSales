namespace CompanyName.ExtendedSummary.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// DTO for the output of extended summary data plugin.
    /// </summary>
    public class ExtendedSummaryOutput(
        List<FieldData> unsummarizedFields,
        BaseSummarySection baseSummarySection,
        List<SummaryContainer> extendedSummarySections
    )
    {
        /// <summary>
        /// List of unsummarized fields that will be passed to GPT for summarization.
        /// </summary>
        public List<FieldData> UnsummarizedFields { get; } = unsummarizedFields;

        /// <summary>
        /// Base summary section added to the main entity summary bullet points.
        /// </summary>
        public BaseSummarySection BaseSummarySection { get; } = baseSummarySection;

        /// <summary>
        /// List of extended summary containers added to the summary card.
        /// </summary>
        public List<SummaryContainer> ExtendedSummarySections { get; set; } = extendedSummarySections;
    }
}
