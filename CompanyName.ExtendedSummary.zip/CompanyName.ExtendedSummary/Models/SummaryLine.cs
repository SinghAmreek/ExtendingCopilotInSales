namespace CompanyName.ExtendedSummary.Models
{
    /// <summary>
    /// Data object for a summary group.
    /// </summary>
    public class SummaryLine(string markdownSummary, string plaintextSummary)
    {
        private protected const string MarkdownSummaryKey = "markdownSummary";
        private protected const string PlaintextSummaryKey = "plaintextSummary";

        /// <summary>
        /// Summary in markdown format (bullet points, links, etc.) 
        /// </summary>
        public string MarkdownSummary { get; set; } = markdownSummary;

        /// <summary>
        /// Same summary as <see cref="MarkdownSummary"/>, in plaintext format.
        /// </summary>
        public string PlaintextSummary { get; set; } = plaintextSummary;
    }
}
