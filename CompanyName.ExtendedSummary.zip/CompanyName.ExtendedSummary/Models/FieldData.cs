namespace CompanyName.ExtendedSummary.Models
{
    using CompanyName.ExtendedSummary.Interfaces;
    using Microsoft.Xrm.Sdk;

    /// <summary>
    /// Data contract for an unsummarized field.
    /// </summary>
    public class FieldData(string logicalName, string displayName, string description, object value) : IResponseItem
    {
        private const string DisplayNameKey = "displayName";
        private const string DescriptionKey = "description";
        private const string ValueKey = "value";

        /// <summary>
        /// Logical name of the field.
        /// </summary>
        public string LogicalName { get; set; } = logicalName;

        /// <summary>
        /// Display name of the field.
        /// </summary>
        public string DisplayName { get; set; } = displayName;

        /// <summary>
        /// Description of the field, used by GPT for additional context.
        /// </summary>
        public string Description { get; set; } = description;

        /// <summary>
        /// Value of the field.
        /// </summary>
        public object Value { get; set; } = value;

        public Entity ToResponseEntity()
        {
            return new()
            {
                Attributes = new()
                {
                    [DisplayNameKey] = DisplayName,
                    [DescriptionKey] = Description,
                    [ValueKey] = Value
                }
            };
        }
    }
}
