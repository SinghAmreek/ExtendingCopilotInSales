namespace CompanyName.ExtendedSummary.Constants
{
    public static class EntityLogicalName
    {
        public const string Account = "account";
        public const string Opportunity = "opportunity";
        public const string Lead = "lead";
    }
}
