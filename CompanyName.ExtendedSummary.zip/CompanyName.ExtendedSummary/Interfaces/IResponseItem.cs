namespace CompanyName.ExtendedSummary.Interfaces
{
    using Microsoft.Xrm.Sdk;

    /// <summary>
    /// Interface for a response item.
    /// </summary>
    public interface IResponseItem
    {
        /// <summary>
        /// Converts the response item to an <see href="https://learn.microsoft.com/en-us/power-apps/developer/data-platform/use-open-types?tabs=sdk#use-entity-as-a-dictionary">entity dictionary</see>.
        /// </summary>
        /// <returns>The entity (dictionary) representation of the response item.</returns>
        public Entity ToResponseEntity();
    }
}
