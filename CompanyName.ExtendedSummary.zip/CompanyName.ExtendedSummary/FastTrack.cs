﻿namespace CompanyName.ExtendedSummary
{
    using System;
    using System.Collections.Generic;
    using System.Text.Json.Serialization;
    using System.Text;
    using CompanyName.ExtendedSummary.Models;
    using Microsoft.Xrm.Sdk;
    using System.Net.Http;
    using Newtonsoft.Json;

    /// <summary>
    /// Dummy data to demonstrate the different types of data outputs in the extended summary response.
    /// </summary>
    public static class FastTrack
    {
        public static BaseSummarySection GetBaseSummarySection(string entityName, string entityId)
        {
            return new(
                "- [Bing](https://www.bing.com/) is a valuable website.\r\n- Bing is owned by [Microsoft](https://en.wikipedia.org/wiki/Microsoft) and has a Credit Limit of $500,000.00.\r\n- Its Ownership structure is Public.",
                "Bing is a valuable website.\r\nBing is owned by Microsoft and has a Credit Limit of $500,000.00.\r\nIts Ownership structure is Public."
            );
        }

        public static List<SummaryContainer> GetSummaryContainers(string entityName, string entityId)
        {
            //return
            //[
            //    new(
            //        "inputDetailsSummarySection",
            //        $"- The entityName is {entityName}.\r\n- The entityId is {entityId}.\r\n- This is the [record link](main.aspx?pagetype=entityrecord&etn={entityName}&id={entityId}).",
            //        $"The entityName is {entityName}.\r\nThe entityId is {entityId}.\r\nThis is the record link.",
            //        0,
            //        "Extended summary insights"
            //    ),
            //    new(
            //        "summary1Key",
            //        "- Copilot is part of [Dynamics 365 Sales](https://www.microsoft.com/en-in/dynamics-365/products/sales).\r\n- Close more deals and increase seller efficiency with an AI-powered CRM solution.\r\n- It has different pricing options.",
            //        "Copilot is part of Dynamics 365 Sales.\r\nClose more deals and increase seller efficiency with an AI-powered CRM solution.\r\nIt has different pricing options.",
            //        2,
            //        "Customer extended summary"
            //    ),
            //];
            string apiUrl = "https://fasttrackcopilotextensionsapi.azure-api.net/clone/api/RelatedActivities?recordType=" + entityName + "&recordId=" + entityId;

            using (HttpClient client = new HttpClient())
            {

                try
                {
                    HttpResponseMessage response = client.GetAsync(apiUrl).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        string responseContent = response.Content.ReadAsStringAsync().Result;
                        RelatedActivities bankAccounts = JsonConvert.DeserializeObject<RelatedActivities>(responseContent);
                        StringBuilder InsightsWithMarkdown = new StringBuilder("This account has " + bankAccounts.Value.Count + " accounts.");
                        StringBuilder InsightsPlainText = new StringBuilder("This account has " + bankAccounts.Value.Count + " accounts:");
                        foreach (var contract in bankAccounts.Value)
                        {
                            InsightsWithMarkdown.Append("\n\n- " + contract.AdditionalProperties["Account Name"].ToString() + "(" + contract.AdditionalProperties["Account Number"].ToString() + ")" + " with the balance of **" + contract.AdditionalProperties["Balance"].ToString() + "**");
                            InsightsPlainText.Append("\n\n " + contract.AdditionalProperties["Account Name"].ToString() + "(" + contract.AdditionalProperties["Account Number"].ToString() + ")" + " with the balance of **:" + contract.AdditionalProperties["Balance"].ToString());

                        }

                        return [
                                new ("BanksAccounts",
                                    InsightsWithMarkdown.ToString(),
                                    InsightsPlainText.ToString(),
                                    1,
                                    "Bank Accounts Summary"
                                    )
                            ];

                        //Console.WriteLine("Flow execution response: " + InsightsWithMarkdown);

                    }
                    else
                    {
                        //Console.WriteLine("Failed to trigger the flow. Status code: " + response.StatusCode
                        return new List<SummaryContainer>();

                    }
                }
                catch (Exception ex)
                {
                    return new List<SummaryContainer>();
                    //throw new Exception("An error occurred ", ex);
                }

            }
        }

        public static List<FieldData> GetFields()
        {
            return
            [
                new(
                    "stockVolatility",
                    "Stock Volatility",
                    "Represents the stock price volatility over the past year.",
                    0.3
                ),
                new(
                    "riskAssessment",
                    "Risk Assessment",
                    "The risk level associated with this account. Can be Low, Medium, or High.",
                    "Low"
                ),
                new("marketShare", "Market Share", "The percentage of market share held by this account.", 15.2),
                new(
                    "ceoContact",
                    "CEO Contact",
                    "The contact record entity reference for the CEO of this account.",
                    new EntityReference("contact", new Guid("678c7b32-3f72-ea11-a811-000d3a1b1f2c"))
                    {
                        Name = "Kevin Martin",
                    }
                ),
            ];
        }
        public class RelatedActivities
        {
            public List<Contract> Value { get; set; }
            public bool HasMoreResults { get; set; }
        }

        public class Contract
        {
            public string Title { get; set; }
            public string Description { get; set; }
            public DateTime DateTime { get; set; }
            public string Url { get; set; }
            public Dictionary<string, string> AdditionalProperties { get; set; }
        }
    }
}
