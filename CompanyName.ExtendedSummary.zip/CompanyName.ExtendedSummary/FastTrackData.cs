﻿namespace CompanyName.ExtendedSummary
{
    using System;
    using System.Collections.Generic;
    using System.Text.Json.Serialization;
    using System.Text;
    using CompanyName.ExtendedSummary.Models;
    using Microsoft.Xrm.Sdk;
    using System.Net.Http;
    using Newtonsoft.Json;

    /// <summary>
    /// Dummy data to demonstrate the different types of data outputs in the extended summary response.
    /// </summary>
    public static class FastTrackData
    {
        public static BaseSummarySection GetBaseSummarySection(string entityName, string entityId)
        {
            return new(
                "- [Bing](https://www.bing.com/) is a valuable website.\r\n- Bing is owned by [Microsoft](https://en.wikipedia.org/wiki/Microsoft) and has a Credit Limit of $500,000.00.\r\n- Its Ownership structure is Public.",
                "Bing is a valuable website.\r\nBing is owned by Microsoft and has a Credit Limit of $500,000.00.\r\nIts Ownership structure is Public."
            );
        }

        public static List<SummaryContainer> GetSummaryContainers(string entityName, string entityId)
        {
           //Add your API URL here
            string apiUrl = "https://salescopilotextensions.azure-api.net/clone/api/RelatedActivities?recordType=" + entityName + "&recordId=" + entityId;

            using (HttpClient client = new HttpClient())
            {

                try
                {
                    HttpResponseMessage response = client.GetAsync(apiUrl).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        string responseContent = response.Content.ReadAsStringAsync().Result;
                        RelatedActivities bankAccounts = JsonConvert.DeserializeObject<RelatedActivities>(responseContent);
                        StringBuilder InsightsWithMarkdown = new StringBuilder("This account has " + bankAccounts.Value.Count + " accounts.");
                        StringBuilder InsightsPlainText = new StringBuilder("This account has " + bankAccounts.Value.Count + " accounts:");
                        foreach (var contract in bankAccounts.Value)
                        {
                            InsightsWithMarkdown.Append("\n\n- " + contract.AdditionalProperties["Account Name"].ToString() + "(" + contract.AdditionalProperties["Account Number"].ToString() + ")" + " with the balance of **" + contract.AdditionalProperties["Balance"].ToString() + "**");
                            InsightsPlainText.Append("\n\n " + contract.AdditionalProperties["Account Name"].ToString() + "(" + contract.AdditionalProperties["Account Number"].ToString() + ")" + " with the balance of **:" + contract.AdditionalProperties["Balance"].ToString());

                        }

                        return [
                                new ("BanksAccounts",
                                    InsightsWithMarkdown.ToString(),
                                    InsightsPlainText.ToString(),
                                    1,
                                    "Bank Accounts Summary"
                                    )
                            ];

                    }

                    else
                    {
                        
                        return new List<SummaryContainer>();

                    }
                }
                catch (Exception ex)
                {
                    return new List<SummaryContainer>();
                    //throw new Exception("An error occurred ", ex);
                }

            }
        }

        public static List<FieldData> GetFields()
        {
            return
            [
                new(
                    "CreditScore",
                    "Credit Score",
                    "Represents the credit score of the customer. Anything greater than 700 is great.",
                    730
                )
            ];
        }
        public class RelatedActivities
        {
            public List<Contract> Value { get; set; }
            public bool HasMoreResults { get; set; }
        }

        public class Contract
        {
            public string Title { get; set; }
            public string Description { get; set; }
            public DateTime DateTime { get; set; }
            public string Url { get; set; }
            public Dictionary<string, string> AdditionalProperties { get; set; }
        }
    }
}
