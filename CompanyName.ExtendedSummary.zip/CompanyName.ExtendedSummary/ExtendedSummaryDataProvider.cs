namespace CompanyName.ExtendedSummary
{
    using System;
    using CompanyName.ExtendedSummary.Models;
    using CompanyName.ExtendedSummary.Services;
    using CompanyName.ExtendedSummary.Utilities;
    using Microsoft.Xrm.Sdk;

    /// <summary>
    /// Customer-defined extended summary data provider logic.
    /// </summary>
    public class ExtendedSummaryDataProvider(string unsecureConfiguration, string secureConfiguration) : IPlugin
    {
        private static class InputParamater
        {
            public const string EntityName = "msdyn_entityName";
            public const string EntityId = "msdyn_entityId";
            public const string ActivityId = "msdyn_activityId";
        }

        public void Execute(IServiceProvider serviceProvider)
        {
            var localPluginContext = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));
            ParameterCollection inputParameters = localPluginContext.InputParameters;

            string entityName = inputParameters[InputParamater.EntityName].ToString();
            string entityId = inputParameters[InputParamater.EntityId].ToString();
            string activityId = inputParameters[InputParamater.ActivityId].ToString();

            // TODO: customer-extended fetch and logic goes in here
            var extendedSummaryDataService = new ExtendedSummaryDataService(
                localPluginContext,
                serviceProvider,
                entityName,
                entityId,
                activityId
            );

            ExtendedSummaryOutput? extendedSummaryOutput = extendedSummaryDataService.GetExtendedSummaryOutput();

            PluginContextUtility.UpdateOutput(localPluginContext, extendedSummaryOutput);
        }
    }
}
